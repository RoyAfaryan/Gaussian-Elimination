import java.util.*;
import java.lang.Math;

public class Main{

    public static void main(String[] args){
/*
 
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the number of linear equations: ");
        int numberOfEquations = scanner.nextInt();
        int numberOfCoefficients = numberOfEquations + 1;
        System.out.println("Please enter coefficients (including b values): ");

        double[][] coefficientMatrix = new double[numberOfEquations][numberOfCoefficients];
        for(int i = 0; i < numberOfEquations; i++){     //loop to enter coefficients
            for(int j = 0; j < numberOfCoefficients; j++){
                coefficientMatrix[i][j] = scanner.nextInt();
            }
        }
/* */
        double[][] coeff = {{0.02, 0.01, 0, 0}, {1, 2, 1, 0}, {0, 1, 2, 1}, {0, 0, 100, 200}};
        
        double[] constant = {0.02, 1, 4, 800};
        
        

        GaussianElimination(coeff, constant);
    }

    public static double[][] GaussianElimination(double[][] matrix, double[] constant){
    	
    	double[] solution = new double[matrix.length];
    	
    	for(int i = 0; i < matrix.length; i++) { //for every equation
    		
    		int maxCoeff = i;
    		for(int j = i + 1; j < matrix.length; j++) {	//Find the largest coefficient in the relevant column 
    			if(Math.abs(matrix[j][i]) > Math.abs(matrix[maxCoeff][i])) {
    				maxCoeff = j;
    			}
    		}
    		
    		System.out.println("init");
    		printMatrix(matrix);
    		
    		swap(matrix, i + 1, maxCoeff + 1); //swap pivot to the top most relevant row
    		
    		System.out.println("after swap");
    		printMatrix(matrix);
    		
    		for(int j = i + 1; j < matrix.length; j++) {
    			double pivotFactor = matrix[j][i] / matrix [i][i];
    			for(int q = i; q < matrix[0].length; q++){
    				matrix[j][q] -= pivotFactor * matrix[i][q];
    			}
    			
    		}
    		System.out.println("after pivot");
    		printMatrix(matrix);
	
    	}
    	

     //back sub goes here
        

     return matrix;
    }

    public static void swap(double[][] matrix, int i, int j){
    	
    	double[] temp = matrix[i - 1];
    	matrix[i - 1] = matrix[j - 1];
    	matrix[j - 1] = temp;
    	
    	
    }
    
    public static void swap(int[] array, int i, int j) {
    	int temp = array[i];
    	array[i] = array[j];
    	array[i] = temp;
    }
    
    public static void forwardElimination(int n, double[][] coeff, double[] constant){
        for(int k = 0; k < n-1; k++){
            for(int i = k+1; i < n; i++){
                double multiplier = coeff[i][k] / coeff[k][k];
                for(int j = k; j < n; j++) {
                    coeff[i][j] -= multiplier*coeff[k][j];
                }
                constant[i] -= multiplier*constant[k];
            }
        }
    }
    
    
    

    public static void printMatrix(double[][] matrix){
        System.out.print("\nCoefficient matrix: \n");
        for(double[]x:matrix){                  
            for(double y:x){
            System.out.print(y+"      ");
            }
            System.out.println();
        }
    }

}